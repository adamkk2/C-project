#include <iostream>
#include <graphics.h>
#include <cmath>
#include "fenetres.h"
#include "figure.h"
#include "dessin.h"
using namespace std;

int main(int argc, char** argv) {
	fenetres f;
	int x,y;
	f.ouvrir_graphique();
	x=f.get_x_max()/2;
	y=f.get_y_max()/2;
	f.allume(x,y,f.get_couleur_fond()+3);
	delay(3000);
	//f.fermer_graphique();
	
	figure head;
	head.set_cercle(x,60,70,3);
	head.dessiner();
	delay(500);	
	
	figure body;
	body.set_rectangle(x,135,60,80,3);
	body.dessiner();
	delay(500);	
	
	figure rh;
	rh.set_droite(body.get_x_min()-30,body.get_y_min()+30,60,-30,3);
	rh.dessiner();
	
	figure lh;
	lh.set_droite(body.get_x_max()+30,body.get_y_min()+30,60,30,3);
	lh.dessiner();
	
	figure rf;
	rf.set_droite(body.get_x_min()+10,body.get_y_max()+30,0,60,3);
	rf.dessiner();
	
	figure lf;
	lf.set_droite(body.get_x_max()-10,body.get_y_max()+30,0,60,3);
	lf.dessiner();

	dessin bonhomme;
	bonhomme.figures[0]=rh;
	bonhomme.figures[1]=body;
	bonhomme.figures[2]=head;
	bonhomme.figures[3]=lh;
	bonhomme.figures[4]=rf;
	bonhomme.figures[5]=lf;
	delay(1000);
	cout << "Part1 succeded";
		delay(1000);
	

	cout << "paet2 succeded" << bonhomme.nb_figures << endl;
	bonhomme.deplacerBM(250,220,f);
	cout << "paet3 succeded";
		
		
	double X, Y, angle;
    double r = y-125;
    const double pi = acos(-1.0);
    cout << y;
    cout << X;
    X = r;
    cout << X;
    for (int i = 0; i<360; i++){
        int xx=X,yy=Y;
        angle = i * pi/180.0;
        X = int(r * sin(angle));
        Y= int(r * cos(angle));
        bonhomme.deplacerBM(X-xx,Y-yy,f);
        delay(25);
    }
	
	delay(5000);
	
	       
	
	
	return 0;
	
}
