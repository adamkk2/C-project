#ifndef FENETRES_H
#define FENETRES_H
#include <graphics.h>


class fenetres
{
	public:
		fenetres(){	}
		void ouvrir_graphique(void){
			initwindow(700,700,"bonhomme");
		}
		void fermer_graphique(void){
			closegraph(-1);
		}
		int get_couleur_fond(void){
			return getbkcolor();
		}
		int get_x_max(void){
			return getmaxx();
		}
		int get_y_max(void){
			return getmaxy();
		}
		int get_couleur(int x, int y){
			return getpixel( x,  y );
		}
		void allume(int x,int y,int c){
			putpixel(x,y,c);
		}
};

#endif
