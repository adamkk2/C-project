#include "figure.h"

#ifndef DESSIN_H
#define DESSIN_H

class dessin
{
	public:
		figure figures [100];
		int  nb_figures;
		
		dessin(){
			this->nb_figures=25;
		}
		

		void deplacerBM(int dx, int dy, fenetres f){
 			for(int i=0;i<this->nb_figures;i++) 
				this->figures[i].deplacer(dx,dy,f);
					
		}
		
};

#endif

